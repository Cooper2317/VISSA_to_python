function VISSA_round=vissa_round(Xcal,ycal,nLV_max,fold,method,num_bms,ratio)
% VISSA: Variable Iterative Space Shrinkage Approach
% Input: 
%        Xcal: The calibration data matrix of size m x n
%        ycal: The calibration response vector of size m x 1
%        nLV_max: The maximum number of latent variable
%        fold: The group number for cross validation
%        method: Pretreatment method
%        num_bms: The number of binray matrix sampling
%        ratio: The ratio of selected sub-models
% Output:
%        VISSA_round: the result of VISSA for one round
% Coded by:       
%        Baichuan Deng, April 3rd 2014
%        dengbaichuan@gmail.com
%        University of Bergen

%        Initial settings
if nargin<7; ratio=0.05;end;
if nargin<6; num_bms=5000;end;
if nargin<5; method=('center');end;
if nargin<4; fold=5;end;
if nargin<3; nLV_max=10;end

[~,n]=size(Xcal);
num_selected_model=num_bms*ratio; %% number of selected model
weight=ones(n,1)*0.5; %% set the initial weight for variables
%weight=ones(n,1)*num_selected_model/2;
W=[weight zeros(n,200)];
meanRMSECV=zeros(1,200);

for i=1:200
    %     generate binary matrix for sampling
    binary_matrix=zeros(num_bms,n);
    for k=1:n
        column=[ones(round(weight(k)*num_bms),1);zeros(num_bms-round(weight(k)*num_bms),1)];
        column=column(randperm(num_bms));
        binary_matrix(:,k)=column;
    end
    
    %     eliminate the rows with all elements zero
    in= sum(binary_matrix,2)==0; % check the rows with all zeros
    binary_matrix(in,:)=1; % change the elements into 1
    
    %     caculate RMSECV for all sub-models
    RMSECV=zeros(1,num_bms);
    for j=1:num_bms
    CV=plscvfold(Xcal(:,binary_matrix(j,:)==1),ycal,nLV_max,fold,method,0,0);
    RMSECV(j)=CV.RMSECV;
    end
    
    %     obtain new weight for sampling
    [RMSECV_sort index]=sort(RMSECV);
    meanRMSECV(i)=mean(RMSECV_sort(1:num_selected_model));
    weight=sum(binary_matrix(index(1:num_selected_model),:))/num_selected_model;
    W(:,i+1)=weight';
    if i>1 && meanRMSECV(i)>=meanRMSECV(i-1)
        break
    end
    fprintf('The %dth binary matrix sampling finished.\n',i);
end

if i<200
meanRMSECV(i+1:200)=[];
W(:,i+2:201)=[];
end

variable_index=binary_matrix(index(1),:)';
nVAR=length(find(variable_index==1));

VISSA_round.meanRMSECV=meanRMSECV; % the mean of RMSECV in each step
VISSA_round.minRMSECV=meanRMSECV(end); % the minimun RMSECV 
VISSA_round.weight=W; % the weights for variables
VISSA_round.variable_index=variable_index; % the index of selected variables
VISSA_round.nVAR=nVAR; % the number of selected variables