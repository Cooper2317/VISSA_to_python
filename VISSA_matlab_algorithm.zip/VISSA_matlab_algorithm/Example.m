load('wheat_kernel.mat')
VISSA=vissa(Xcal,ycal,10,5,'center',5000,0.05);
CV=plscvfold(Xcal(:,VISSA.variable_index==1),ycal,10,5,'center',0,0);
[rmsep,rmsec]=predict(Xcal,ycal,Xtest,ytest,VISSA.variable_index==1,CV.optPC,5,'center');
