function VISSA=vissa(Xcal,ycal,nLV_max,fold,method,num_bms,ratio)
% VISSA: Variable Iterative Space Shrinkage Approach
% Input: 
%        Xcal: The calibration data matrix of size m x n
%        ycal: The calibration response vector of size m x 1
%        nLV_max: The maximum number of latent variable
%        fold: The group number for cross validation
%        method: Pretreatment method
%        num_bms: The number of binray matrix sampling
%        ratio: The ratio of selected sub-models
% Output:
%        VISSA: the result of VISSA
% Coded by:       
%        Baichuan Deng, April 3rd 2014
%        dengbaichuan@gmail.com
%        University of Bergen

%        Initial settings
if nargin<7; ratio=0.05;end;
if nargin<6; num_bms=5000;end;
if nargin<5; method=('center');end;
if nargin<4; fold=5;end;
if nargin<3; nLV_max=10;end

[~,n]=size(Xcal);
Variable_index=ones(n,1);
RMSECV=[];
for k=1:100
    index= find(Variable_index(:,end)==1);
    VISSA_round=vissa_round(Xcal(:,index),ycal,nLV_max,fold,method,num_bms,ratio);
    RMSECV=[RMSECV VISSA_round.minRMSECV];
    if k>1&&RMSECV(end)>=RMSECV(end-1)
        break
    end
    v= index(VISSA_round.variable_index==1);
    variable_index=zeros(n,1);
    variable_index(v)=1;
    Variable_index=[Variable_index variable_index];
    fprintf('The %dth vissa round finished.\n',k);
end

nVAR=length(find(Variable_index(:,end)==1));

VISSA.RMSECV=RMSECV;% the RMSECV in each round
VISSA.minRMSECV=RMSECV(end); % the final RMSECV
VISSA.Variable_index=Variable_index; % the variable index in each round
VISSA.variable_index=Variable_index(:,end); % the final variable index
VISSA_round.nVAR=nVAR; % the final number of variables
